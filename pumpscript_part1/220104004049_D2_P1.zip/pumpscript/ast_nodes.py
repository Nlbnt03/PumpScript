# =============================================================
#  PumpScript AST Nodes
#  CSE 341 — Concepts of Programming Languages
#  Gebze Technical University
# =============================================================
#
#  Each class represents one node type in the Abstract Syntax Tree.
#  The parser builds a tree of these nodes; the interpreter
#  (Part 2) will walk the tree to execute the program.
#
#  Hierarchy:
#    Program
#    ├── RoutineDecl
#    │   ├── Param (x N)
#    │   └── Block
#    │       └── Statement (x N)
#    └── Statement (x N)
#        ├── ExerciseBlock
#        │   └── Field (x N)
#        ├── RestStmt
#        ├── RepeatStmt
#        │   └── Block
#        ├── IfStmt
#        │   ├── Block (then)
#        │   └── Block (else, optional)
#        └── RoutineCall
#
#  Expressions:
#    BinOp, UnaryOp, Literal, Ident
# =============================================================


class Node:
    """Base class for all AST nodes."""
    def dump(self, indent: int = 0) -> str:
        raise NotImplementedError


def _ind(indent: int) -> str:
    """Return indentation string."""
    return "  " * indent


# =============================================================
#  Top-level
# =============================================================

class Program(Node):
    """
    Root node of the AST.
    Contains a list of top-level declarations and statements.
    """
    def __init__(self, body: list):
        self.body = body   # list of RoutineDecl | Statement nodes

    def dump(self, indent=0):
        lines = [_ind(indent) + "Program"]
        for node in self.body:
            lines.append(node.dump(indent + 1))
        return "\n".join(lines)


# =============================================================
#  Routine declaration
# =============================================================

class Param(Node):
    """A single parameter: name : type  (e.g., sets : int)"""
    def __init__(self, name: str, type_: str, line: int):
        self.name  = name
        self.type_ = type_
        self.line  = line

    def dump(self, indent=0):
        return _ind(indent) + f"Param({self.name}: {self.type_})"


class RoutineDecl(Node):
    """
    routine <name>(<params>) <block>
    """
    def __init__(self, name: str, params: list, body, line: int):
        self.name   = name    # str
        self.params = params  # list of Param
        self.body   = body    # Block
        self.line   = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"RoutineDecl({self.name})"]
        for p in self.params:
            lines.append(p.dump(indent + 1))
        lines.append(self.body.dump(indent + 1))
        return "\n".join(lines)


# =============================================================
#  Block
# =============================================================

class Block(Node):
    """{ <statement>* }"""
    def __init__(self, stmts: list, line: int):
        self.stmts = stmts
        self.line  = line

    def dump(self, indent=0):
        lines = [_ind(indent) + "Block"]
        for s in self.stmts:
            lines.append(s.dump(indent + 1))
        return "\n".join(lines)


# =============================================================
#  Statements
# =============================================================

class Field(Node):
    """A single field inside an exercise block: name : expr"""
    def __init__(self, name: str, value, line: int):
        self.name  = name   # str
        self.value = value  # expression node
        self.line  = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"Field({self.name})"]
        lines.append(self.value.dump(indent + 1))
        return "\n".join(lines)


class ExerciseBlock(Node):
    """
    exercise <name> { <field>* }
    Domain-specific construct: represents one exercise record.
    """
    def __init__(self, name: str, fields: list, line: int):
        self.name   = name    # str
        self.fields = fields  # list of Field
        self.line   = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"ExerciseBlock({self.name})"]
        for f in self.fields:
            lines.append(f.dump(indent + 1))
        return "\n".join(lines)


class RestStmt(Node):
    """
    rest <int_lit> seconds
    Domain-specific construct: rest period between exercises.
    """
    def __init__(self, seconds: int, line: int):
        self.seconds = seconds
        self.line    = line

    def dump(self, indent=0):
        return _ind(indent) + f"RestStmt(seconds={self.seconds})"


class RepeatStmt(Node):
    """repeat <int_lit> times <block>"""
    def __init__(self, count: int, body, line: int):
        self.count = count  # int
        self.body  = body   # Block
        self.line  = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"RepeatStmt(count={self.count})"]
        lines.append(self.body.dump(indent + 1))
        return "\n".join(lines)


class IfStmt(Node):
    """if <expr> <block> [ else <block> ]"""
    def __init__(self, condition, then_block, else_block, line: int):
        self.condition  = condition   # expression node
        self.then_block = then_block  # Block
        self.else_block = else_block  # Block or None
        self.line       = line

    def dump(self, indent=0):
        lines = [_ind(indent) + "IfStmt"]
        lines.append(_ind(indent + 1) + "Condition:")
        lines.append(self.condition.dump(indent + 2))
        lines.append(_ind(indent + 1) + "Then:")
        lines.append(self.then_block.dump(indent + 2))
        if self.else_block:
            lines.append(_ind(indent + 1) + "Else:")
            lines.append(self.else_block.dump(indent + 2))
        return "\n".join(lines)


class RoutineCall(Node):
    """<name>(<args>)"""
    def __init__(self, name: str, args: list, line: int):
        self.name = name   # str
        self.args = args   # list of expression nodes
        self.line = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"RoutineCall({self.name})"]
        for a in self.args:
            lines.append(a.dump(indent + 1))
        return "\n".join(lines)


# =============================================================
#  Expressions
# =============================================================

class BinOp(Node):
    """Binary operation: left op right"""
    def __init__(self, op: str, left, right, line: int):
        self.op    = op
        self.left  = left
        self.right = right
        self.line  = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"BinOp({self.op})"]
        lines.append(self.left.dump(indent + 1))
        lines.append(self.right.dump(indent + 1))
        return "\n".join(lines)


class UnaryOp(Node):
    """Unary minus: -<primary>"""
    def __init__(self, op: str, operand, line: int):
        self.op      = op
        self.operand = operand
        self.line    = line

    def dump(self, indent=0):
        lines = [_ind(indent) + f"UnaryOp({self.op})"]
        lines.append(self.operand.dump(indent + 1))
        return "\n".join(lines)


class Literal(Node):
    """A literal value: int, float, string, or bool"""
    def __init__(self, type_: str, value, line: int):
        self.type_  = type_   # "int", "float", "string", "bool"
        self.value  = value   # Python value
        self.line   = line

    def dump(self, indent=0):
        return _ind(indent) + f"Literal({self.type_}, {self.value!r})"


class Ident(Node):
    """An identifier reference (variable or parameter name)"""
    def __init__(self, name: str, line: int):
        self.name = name
        self.line = line

    def dump(self, indent=0):
        return _ind(indent) + f"Ident({self.name})"
