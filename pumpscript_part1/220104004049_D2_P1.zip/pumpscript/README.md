# PumpScript — Interpreter (Part 1)
CSE 341 · Concepts of Programming Languages · Gebze Technical University

## What is PumpScript?
PumpScript is a domain-specific language for defining and managing workout routines.

## Requirements
- Python 3.8 or higher
- No external libraries required

## File Structure
```
pumpscript/
├── pumpscript.py   ← main entry point
├── lexer.py        ← tokenizer
├── parser.py       ← recursive-descent parser
├── ast_nodes.py    ← AST node definitions
├── README.md       ← this file
└── examples/
    ├── valid1.pump ← chest day routine
    ├── valid2.pump ← leg day routine
    ├── valid3.pump ← full body routine
    ├── error1.pump ← missing closing brace
    ├── error2.pump ← invalid character
    ├── error3.pump ← missing type annotation
    ├── error4.pump ← unterminated string
    └── error5.pump ← unexpected token
```

## How to Run

### Parse a file (check for syntax errors):
```bash
python pumpscript.py examples/valid1.pump
```

### Parse and dump the AST:
```bash
python pumpscript.py examples/valid1.pump --dump-ast
```

### Expected output for a valid file:
```
[OK] 'examples/valid1.pump' parsed successfully.
```

### Expected output with --dump-ast:
```
Program
  RoutineDecl(chest_day)
    Param(sets: int)
    Block
      ExerciseBlock(bench_press)
        Field(sets)
          Ident(sets)
        Field(reps)
          Literal(int, 10)
        ...
```

### Expected output for an invalid file:
```
[Parse Error] Line 3: Expected '}' but found 'exercise'
```

## Language Overview

### Primitive Types
| Type   | Example        |
|--------|----------------|
| int    | 4, 10, 90      |
| float  | 80.0, 100.5    |
| string | "legs", "chest"|
| bool   | true, false    |

### Structured Type
```
exercise bench_press {
    sets:      4
    reps:      10
    weight:    80.0
    group:     "chest"
    completed: false
}
```

### Control Structures
```
repeat 3 times { ... }
if completed == false { ... } else { ... }
```

### Routines (User-defined functions)
```
routine chest_day(sets: int) {
    exercise bench_press { ... }
    rest 60 seconds
}
chest_day(4)
```

### Domain-specific construct
```
rest 90 seconds   // rest period between exercises
```
