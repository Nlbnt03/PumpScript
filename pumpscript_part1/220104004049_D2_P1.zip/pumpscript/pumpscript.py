# =============================================================
#  PumpScript — Main Entry Point
#  CSE 341 — Concepts of Programming Languages
#  Gebze Technical University
# =============================================================
#
#  Usage:
#    python pumpscript.py <file.pump>             # parse only
#    python pumpscript.py <file.pump> --dump-ast  # show AST
#
#  Exit codes:
#    0 — success
#    1 — lexer or parser error
# =============================================================

import sys
from lexer  import Lexer,  LexerError
from parser import Parser, ParseError


def main():
    # ----------------------------------------------------------
    #  Argument parsing
    # ----------------------------------------------------------
    args = sys.argv[1:]

    if not args:
        print("Usage: python pumpscript.py <file.pump> [--dump-ast]")
        sys.exit(1)

    source_file = args[0]
    dump_ast    = "--dump-ast" in args

    # ----------------------------------------------------------
    #  Read source file
    # ----------------------------------------------------------
    try:
        with open(source_file, "r", encoding="utf-8") as f:
            source = f.read()
    except FileNotFoundError:
        print(f"[Error] File not found: '{source_file}'")
        sys.exit(1)

    # ----------------------------------------------------------
    #  Lexing
    # ----------------------------------------------------------
    try:
        lexer  = Lexer(source)
        tokens = lexer.tokenize()
    except LexerError as e:
        print(str(e))
        sys.exit(1)

    # ----------------------------------------------------------
    #  Parsing
    # ----------------------------------------------------------
    try:
        parser = Parser(tokens)
        ast    = parser.parse()
    except ParseError as e:
        print(str(e))
        sys.exit(1)

    # ----------------------------------------------------------
    #  Output
    # ----------------------------------------------------------
    if dump_ast:
        print(ast.dump())
    else:
        print(f"[OK] '{source_file}' parsed successfully.")


if __name__ == "__main__":
    main()
