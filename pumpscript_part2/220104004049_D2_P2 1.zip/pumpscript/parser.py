# =============================================================
#  PumpScript Parser
#  CSE 341 — Concepts of Programming Languages
#  Gebze Technical University
# =============================================================
#
#  Recursive-descent parser.
#  Each method corresponds to one EBNF rule.
#
#  EBNF → Method mapping:
#    <program>        → parse_program()
#    <routine_decl>   → parse_routine_decl()
#    <block>          → parse_block()
#    <statement>      → parse_statement()
#    <exercise_block> → parse_exercise_block()
#    <rest_stmt>      → parse_rest_stmt()
#    <repeat_stmt>    → parse_repeat_stmt()
#    <if_stmt>        → parse_if_stmt()
#    <routine_call>   → parse_routine_call()
#    <expr>           → parse_expr()
#    <comparison>     → parse_comparison()
#    <term>           → parse_term()
#    <factor>         → parse_factor()
#    <unary>          → parse_unary()
#    <primary>        → parse_primary()
# =============================================================

from lexer    import Lexer, Token
from ast_nodes import (
    Program, RoutineDecl, Param, Block,
    ExerciseBlock, Field, RestStmt, RepeatStmt,
    IfStmt, RoutineCall,
    BinOp, UnaryOp, Literal, Ident
)


# =============================================================
#  ParseError
# =============================================================
class ParseError(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"[Parse Error] Line {line}: {message}")
        self.line = line


# =============================================================
#  Parser
# =============================================================
class Parser:
    """
    Recursive-descent parser for PumpScript.

    Usage
    -----
        lexer  = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast    = parser.parse()
    """

    def __init__(self, tokens: list):
        self.tokens = tokens
        self.pos    = 0        # index into token list

    # ----------------------------------------------------------
    #  Token navigation helpers
    # ----------------------------------------------------------

    def current(self) -> Token:
        """Return the token at the current position."""
        return self.tokens[self.pos]

    def peek(self) -> Token:
        """Return the NEXT token without advancing."""
        if self.pos + 1 < len(self.tokens):
            return self.tokens[self.pos + 1]
        return self.tokens[-1]   # EOF

    def advance(self) -> Token:
        """Consume and return the current token."""
        tok = self.tokens[self.pos]
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return tok

    def expect(self, type_: str, value: str = None) -> Token:
        """
        Consume the current token if it matches type_ (and value).
        Raise ParseError otherwise.
        This is the main error-reporting mechanism.
        """
        tok = self.current()

        if tok.type != type_:
            expected = f"'{value}'" if value else type_
            raise ParseError(
                f"Expected {expected} but found '{tok.value}'",
                tok.line
            )

        if value is not None and tok.value != value:
            raise ParseError(
                f"Expected '{value}' but found '{tok.value}'",
                tok.line
            )

        return self.advance()

    def match(self, type_: str, value: str = None) -> bool:
        """
        Return True if the current token matches without consuming.
        """
        tok = self.current()
        if tok.type != type_:
            return False
        if value is not None and tok.value != value:
            return False
        return True

    # ----------------------------------------------------------
    #  Entry point
    # ----------------------------------------------------------

    def parse(self) -> Program:
        """
        <program> = { <routine_decl> | <statement> }
        """
        body = []
        while not self.match("EOF"):
            if self.match("KEYWORD", "routine"):
                body.append(self.parse_routine_decl())
            else:
                body.append(self.parse_statement())
        return Program(body)

    # ----------------------------------------------------------
    #  Routine declaration
    # ----------------------------------------------------------

    def parse_routine_decl(self) -> RoutineDecl:
        """
        <routine_decl> = "routine" IDENT "(" [ <param_list> ] ")" <block>
        """
        line = self.current().line
        self.expect("KEYWORD", "routine")

        name = self.expect("IDENT").value

        self.expect("SEP", "(")
        params = []
        if not self.match("SEP", ")"):
            params = self.parse_param_list()
        self.expect("SEP", ")")

        body = self.parse_block()
        return RoutineDecl(name, params, body, line)

    def parse_param_list(self) -> list:
        """
        <param_list> = <param> { "," <param> }
        """
        params = [self.parse_param()]
        while self.match("SEP", ","):
            self.advance()   # consume ","
            params.append(self.parse_param())
        return params

    def parse_param(self) -> Param:
        """
        <param> = IDENT ":" <type>
        """
        line = self.current().line
        name = self.expect("IDENT").value
        self.expect("SEP", ":")
        type_ = self.parse_type()
        return Param(name, type_, line)

    def parse_type(self) -> str:
        """
        <type> = "int" | "float" | "string" | "bool"
        """
        tok = self.current()
        if tok.type == "KEYWORD" and tok.value in ("int", "float", "string", "bool"):
            return self.advance().value
        raise ParseError(
            f"Expected a type (int, float, string, bool) but found '{tok.value}'",
            tok.line
        )

    # ----------------------------------------------------------
    #  Block
    # ----------------------------------------------------------

    def parse_block(self) -> Block:
        """
        <block> = "{" { <statement> } "}"
        """
        line = self.current().line
        self.expect("SEP", "{")
        stmts = []
        while not self.match("SEP", "}") and not self.match("EOF"):
            stmts.append(self.parse_statement())
        self.expect("SEP", "}")
        return Block(stmts, line)

    # ----------------------------------------------------------
    #  Statement dispatcher
    # ----------------------------------------------------------

    def parse_statement(self):
        """
        <statement> = <exercise_block>
                    | <rest_stmt>
                    | <repeat_stmt>
                    | <if_stmt>
                    | <routine_call>
        """
        tok = self.current()

        if tok.type == "KEYWORD":
            if tok.value == "exercise":
                return self.parse_exercise_block()
            elif tok.value == "rest":
                return self.parse_rest_stmt()
            elif tok.value == "repeat":
                return self.parse_repeat_stmt()
            elif tok.value == "if":
                return self.parse_if_stmt()

        # Must be a routine call: IDENT "(" ...
        if tok.type == "IDENT":
            return self.parse_routine_call()

        raise ParseError(
            f"Unexpected token '{tok.value}' — expected a statement",
            tok.line
        )

    # ----------------------------------------------------------
    #  Exercise block
    # ----------------------------------------------------------

    def parse_exercise_block(self) -> ExerciseBlock:
        """
        <exercise_block> = "exercise" IDENT "{" { <field> } "}"
        """
        line = self.current().line
        self.expect("KEYWORD", "exercise")
        name = self.expect("IDENT").value
        self.expect("SEP", "{")

        fields = []
        while not self.match("SEP", "}") and not self.match("EOF"):
            fields.append(self.parse_field())

        self.expect("SEP", "}")
        return ExerciseBlock(name, fields, line)

    def parse_field(self) -> Field:
        """
        <field> = IDENT ":" <expr>
        """
        line = self.current().line
        name = self.expect("IDENT").value
        self.expect("SEP", ":")
        value = self.parse_expr()
        return Field(name, value, line)

    # ----------------------------------------------------------
    #  Rest statement
    # ----------------------------------------------------------

    def parse_rest_stmt(self) -> RestStmt:
        """
        <rest_stmt> = "rest" INT_LIT "seconds"
        """
        line = self.current().line
        self.expect("KEYWORD", "rest")
        seconds_tok = self.expect("INT_LIT")
        self.expect("KEYWORD", "seconds")
        return RestStmt(int(seconds_tok.value), line)

    # ----------------------------------------------------------
    #  Repeat statement
    # ----------------------------------------------------------

    def parse_repeat_stmt(self) -> RepeatStmt:
        """
        <repeat_stmt> = "repeat" INT_LIT "times" <block>
        """
        line = self.current().line
        self.expect("KEYWORD", "repeat")
        count_tok = self.expect("INT_LIT")
        self.expect("KEYWORD", "times")
        body = self.parse_block()
        return RepeatStmt(int(count_tok.value), body, line)

    # ----------------------------------------------------------
    #  If statement
    # ----------------------------------------------------------

    def parse_if_stmt(self) -> IfStmt:
        """
        <if_stmt> = "if" <expr> <block> [ "else" <block> ]
        """
        line = self.current().line
        self.expect("KEYWORD", "if")
        condition  = self.parse_expr()
        then_block = self.parse_block()

        else_block = None
        if self.match("KEYWORD", "else"):
            self.advance()   # consume "else"
            else_block = self.parse_block()

        return IfStmt(condition, then_block, else_block, line)

    # ----------------------------------------------------------
    #  Routine call
    # ----------------------------------------------------------

    def parse_routine_call(self) -> RoutineCall:
        """
        <routine_call> = IDENT "(" [ <arg_list> ] ")"
        """
        line = self.current().line
        name = self.expect("IDENT").value
        self.expect("SEP", "(")

        args = []
        if not self.match("SEP", ")"):
            args = self.parse_arg_list()

        self.expect("SEP", ")")
        return RoutineCall(name, args, line)

    def parse_arg_list(self) -> list:
        """
        <arg_list> = <expr> { "," <expr> }
        """
        args = [self.parse_expr()]
        while self.match("SEP", ","):
            self.advance()
            args.append(self.parse_expr())
        return args

    # ----------------------------------------------------------
    #  Expressions — precedence encoded bottom-up
    # ----------------------------------------------------------

    def parse_expr(self):
        """
        <expr> = <comparison> { ("==" | "!=") <comparison> }
        Lowest precedence: equality operators.
        """
        left = self.parse_comparison()
        while self.match("OP", "==") or self.match("OP", "!="):
            op   = self.advance().value
            right = self.parse_comparison()
            left  = BinOp(op, left, right, left.line)
        return left

    def parse_comparison(self):
        """
        <comparison> = <term> { (">" | "<" | ">=" | "<=") <term> }
        """
        left = self.parse_term()
        while self.current().type == "OP" and \
              self.current().value in (">", "<", ">=", "<="):
            op    = self.advance().value
            right = self.parse_term()
            left  = BinOp(op, left, right, left.line)
        return left

    def parse_term(self):
        """
        <term> = <factor> { ("+" | "-") <factor> }
        """
        left = self.parse_factor()
        while self.match("OP", "+") or self.match("OP", "-"):
            op    = self.advance().value
            right = self.parse_factor()
            left  = BinOp(op, left, right, left.line)
        return left

    def parse_factor(self):
        """
        <factor> = <unary> { ("*" | "/") <unary> }
        Highest binary operator precedence.
        """
        left = self.parse_unary()
        while self.match("OP", "*") or self.match("OP", "/"):
            op    = self.advance().value
            right = self.parse_unary()
            left  = BinOp(op, left, right, left.line)
        return left

    def parse_unary(self):
        """
        <unary> = "-" <primary> | <primary>
        """
        if self.match("OP", "-"):
            line = self.current().line
            self.advance()
            operand = self.parse_primary()
            return UnaryOp("-", operand, line)
        return self.parse_primary()

    def parse_primary(self):
        """
        <primary> = INT_LIT | FLOAT_LIT | STRING_LIT
                  | "true" | "false"
                  | IDENT
                  | "(" <expr> ")"
        """
        tok = self.current()

        if tok.type == "INT_LIT":
            self.advance()
            return Literal("int", int(tok.value), tok.line)

        if tok.type == "FLOAT_LIT":
            self.advance()
            return Literal("float", float(tok.value), tok.line)

        if tok.type == "STRING_LIT":
            self.advance()
            return Literal("string", tok.value, tok.line)

        if tok.type == "KEYWORD" and tok.value == "true":
            self.advance()
            return Literal("bool", True, tok.line)

        if tok.type == "KEYWORD" and tok.value == "false":
            self.advance()
            return Literal("bool", False, tok.line)

        if tok.type == "IDENT":
            self.advance()
            return Ident(tok.value, tok.line)

        if tok.type == "SEP" and tok.value == "(":
            self.advance()        # consume "("
            expr = self.parse_expr()
            self.expect("SEP", ")")
            return expr

        raise ParseError(
            f"Unexpected token '{tok.value}' in expression",
            tok.line
        )


# =============================================================
#  Quick test — run this file directly: python parser.py
# =============================================================
if __name__ == "__main__":
    sample = """
// Chest day routine
routine chest_day(sets: int) {
    exercise bench_press {
        sets:      sets
        reps:      10
        weight:    80.0
        group:     "chest"
        completed: false
    }
    rest 60 seconds
    exercise chest_fly {
        sets:      sets
        reps:      12
        weight:    20.0
        group:     "chest"
        completed: false
    }
}

// Leg day routine
routine leg_day(sets: int) {
    exercise squat {
        sets:      sets
        reps:      8
        weight:    100.0
        group:     "legs"
        completed: false
    }
    rest 90 seconds
    exercise lunges {
        sets:      3
        reps:      12
        weight:    0.0
        group:     "legs"
        completed: false
    }
}

if true {
    repeat 3 times {
        chest_day(4)
    }
}
leg_day(4)
"""
    from lexer import Lexer
    lexer  = Lexer(sample)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    ast    = parser.parse()
    print(ast.dump())
