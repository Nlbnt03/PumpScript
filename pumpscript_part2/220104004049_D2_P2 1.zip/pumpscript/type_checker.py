# =============================================================
#  PumpScript Type Checker
#  CSE 341 — Concepts of Programming Languages
#  Gebze Technical University
# =============================================================
#
#  Type system decisions:
#  - Strong typing: mismatched types raise TypeError before execution
#  - Coercion: int is implicitly widened to float (e.g., weight: 80 → 80.0)
#              float is NOT narrowed to int
#  - Type equivalence: name equivalence for exercise records
#
#  What is checked:
#  1. Exercise field types match expected types
#  2. Routine call argument types match parameter types
#  3. if condition must be a bool expression
#  4. Binary operator operand types are compatible
# =============================================================

from ast_nodes import (
    Program, RoutineDecl, Param, Block,
    ExerciseBlock, Field, RestStmt, RepeatStmt,
    IfStmt, RoutineCall,
    BinOp, UnaryOp, Literal, Ident
)


# =============================================================
#  Expected field types for exercise records
#  (name equivalence: enforced by field name)
# =============================================================
EXERCISE_FIELD_TYPES = {
    "sets":      "int",
    "reps":      "int",
    "weight":    "float",
    "group":     "string",
    "completed": "bool",
}


# =============================================================
#  TypeError
# =============================================================
class TypeErrorPS(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"[Type Error] Line {line}: {message}")
        self.line = line


# =============================================================
#  Compatibility check (coercion rule)
# =============================================================
def is_compatible(expected: str, actual: str) -> bool:
    """
    Return True if actual type is compatible with expected type.
    Coercion rule: int is widened to float, not the reverse.
    """
    if expected == actual:
        return True
    # int → float coercion (Sebesta §7.4)
    if expected == "float" and actual == "int":
        return True
    return False


# =============================================================
#  Type Checker
# =============================================================
class TypeChecker:
    """
    Walks the AST and verifies type consistency.

    Usage
    -----
        checker = TypeChecker()
        checker.check(ast)   # raises TypeErrorPS on failure
    """

    def __init__(self):
        # Maps routine name → list of (param_name, param_type)
        self.routines = {}
        # Current local type environment: name → type
        self.type_env = {}

    # ----------------------------------------------------------
    #  Entry point
    # ----------------------------------------------------------
    def check(self, program: Program):
        """
        Two-pass checking:
        Pass 1 — collect all routine signatures (so forward calls work)
        Pass 2 — type-check all statements
        """
        # Pass 1: collect routine signatures
        for node in program.body:
            if isinstance(node, RoutineDecl):
                self.routines[node.name] = [
                    (p.name, p.type_) for p in node.params
                ]

        # Pass 2: check everything
        for node in program.body:
            self.check_node(node)

    # ----------------------------------------------------------
    #  Node dispatcher
    # ----------------------------------------------------------
    def check_node(self, node):
        if isinstance(node, RoutineDecl):
            self.check_routine_decl(node)
        elif isinstance(node, ExerciseBlock):
            self.check_exercise_block(node)
        elif isinstance(node, RestStmt):
            pass   # rest N seconds — no type checking needed
        elif isinstance(node, RepeatStmt):
            self.check_block(node.body)
        elif isinstance(node, IfStmt):
            self.check_if_stmt(node)
        elif isinstance(node, RoutineCall):
            self.check_routine_call(node)
        elif isinstance(node, Block):
            self.check_block(node)

    # ----------------------------------------------------------
    #  Routine declaration
    # ----------------------------------------------------------
    def check_routine_decl(self, node: RoutineDecl):
        """
        Add parameters to local type environment,
        then check the routine body.
        """
        # Save outer environment, create new local scope
        outer_env = self.type_env.copy()

        for param in node.params:
            self.type_env[param.name] = param.type_

        self.check_block(node.body)

        # Restore outer environment (static scoping)
        self.type_env = outer_env

    # ----------------------------------------------------------
    #  Block
    # ----------------------------------------------------------
    def check_block(self, block: Block):
        for stmt in block.stmts:
            self.check_node(stmt)

    # ----------------------------------------------------------
    #  Exercise block
    # ----------------------------------------------------------
    def check_exercise_block(self, node: ExerciseBlock):
        """
        Check that an exercise block has exactly the expected field schema and
        that every field expression has the declared type.
        Applies int→float coercion for the 'weight' field.
        """
        seen_fields = set()

        for field in node.fields:
            if field.name not in EXERCISE_FIELD_TYPES:
                raise TypeErrorPS(
                    f"In exercise '{node.name}': unknown field '{field.name}'",
                    field.line
                )

            if field.name in seen_fields:
                raise TypeErrorPS(
                    f"In exercise '{node.name}': duplicate field '{field.name}'",
                    field.line
                )
            seen_fields.add(field.name)

            actual_type = self.get_type(field.value, field.line)
            expected_type = EXERCISE_FIELD_TYPES[field.name]

            if not is_compatible(expected_type, actual_type):
                raise TypeErrorPS(
                    f"In exercise '{node.name}': "
                    f"field '{field.name}' expects {expected_type} "
                    f"but got {actual_type}",
                    field.line
                )

        missing = [name for name in EXERCISE_FIELD_TYPES if name not in seen_fields]
        if missing:
            raise TypeErrorPS(
                f"In exercise '{node.name}': missing field(s): {', '.join(missing)}",
                node.line
            )

    # ----------------------------------------------------------
    #  If statement
    # ----------------------------------------------------------
    def check_if_stmt(self, node: IfStmt):
        """
        Condition must evaluate to bool.
        """
        cond_type = self.get_type(node.condition, node.line)
        if cond_type != "bool":
            raise TypeErrorPS(
                f"'if' condition must be bool but got {cond_type}",
                node.line
            )
        self.check_block(node.then_block)
        if node.else_block:
            self.check_block(node.else_block)

    # ----------------------------------------------------------
    #  Routine call
    # ----------------------------------------------------------
    def check_routine_call(self, node: RoutineCall):
        """
        Check that argument types match declared parameter types.
        """
        if node.name not in self.routines:
            raise TypeErrorPS(
                f"Call to undefined routine '{node.name}'",
                node.line
            )

        params = self.routines[node.name]

        if len(node.args) != len(params):
            raise TypeErrorPS(
                f"Routine '{node.name}' expects {len(params)} argument(s) "
                f"but got {len(node.args)}",
                node.line
            )

        for (param_name, param_type), arg in zip(params, node.args):
            arg_type = self.get_type(arg, node.line)
            if not is_compatible(param_type, arg_type):
                raise TypeErrorPS(
                    f"Routine '{node.name}': "
                    f"parameter '{param_name}' expects {param_type} "
                    f"but got {arg_type}",
                    node.line
                )

    # ----------------------------------------------------------
    #  Type inference for expressions
    # ----------------------------------------------------------
    def get_type(self, node, line: int) -> str:
        """
        Infer the type of an expression node.
        Returns: "int", "float", "string", or "bool"
        """

        # Literal: type is known directly
        if isinstance(node, Literal):
            return node.type_

        # Identifier: look up in the current static type environment.
        # PumpScript has no implicit globals or undeclared variables, so an
        # unknown identifier is a static type error rather than a runtime guess.
        if isinstance(node, Ident):
            if node.name in self.type_env:
                return self.type_env[node.name]
            raise TypeErrorPS(
                f"Undefined identifier '{node.name}'",
                getattr(node, "line", line)
            )

        # Unary minus: operand must be int or float
        if isinstance(node, UnaryOp):
            operand_type = self.get_type(node.operand, line)
            if operand_type not in ("int", "float"):
                raise TypeErrorPS(
                    f"Unary '-' applied to {operand_type}, expected int or float",
                    line
                )
            return operand_type

        # Binary operation
        if isinstance(node, BinOp):
            return self.get_binop_type(node, line)

        return "unknown"

    # ----------------------------------------------------------
    #  Binary operator type rules
    # ----------------------------------------------------------
    def get_binop_type(self, node: BinOp, line: int) -> str:
        """
        Arithmetic: int op int → int, float op float → float,
                    int op float or float op int → float (coercion)
        Comparison: both sides same (or coercible) → bool
        Equality:   both sides same (or coercible) → bool
        """
        left_type  = self.get_type(node.left,  line)
        right_type = self.get_type(node.right, line)

        # Relational comparison operators: numeric only, result is bool.
        if node.op in (">", "<", ">=", "<="):
            if left_type in ("int", "float") and right_type in ("int", "float"):
                return "bool"
            raise TypeErrorPS(
                f"Cannot compare {left_type} with {right_type} using '{node.op}'",
                line
            )

        # Equality operators: compatible primitive values only, result is bool.
        if node.op in ("==", "!="):
            if left_type == right_type:
                return "bool"
            if left_type in ("int", "float") and right_type in ("int", "float"):
                return "bool"   # int ↔ float equality allowed through widening
            raise TypeErrorPS(
                f"Cannot compare {left_type} with {right_type} using '{node.op}'",
                line
            )

        # Arithmetic operators: numeric only.
        if node.op in ("+", "-", "*", "/"):
            if not (left_type in ("int", "float") and right_type in ("int", "float")):
                raise TypeErrorPS(
                    f"Cannot apply '{node.op}' to {left_type} and {right_type}",
                    line
                )
            if node.op == "/":
                return "float"  # division always returns float
            if left_type == "float" or right_type == "float":
                return "float"
            return "int"

        return "unknown"


# =============================================================
#  Quick test — python type_checker.py
# =============================================================
if __name__ == "__main__":
    from lexer  import Lexer
    from parser import Parser

    # --- Valid program ---
    valid = """
routine chest_day(sets: int) {
    exercise bench_press {
        sets:      sets
        reps:      10
        weight:    80
        group:     "chest"
        completed: false
    }
    rest 60 seconds
}
chest_day(4)
"""
    # --- Type error: wrong type for weight ---
    invalid = """
routine leg_day(sets: int) {
    exercise squat {
        sets:      sets
        reps:      8
        weight:    "heavy"
        group:     "legs"
        completed: false
    }
}
leg_day(4)
"""
    # --- Type error: wrong argument type ---
    invalid2 = """
routine chest_day(sets: int) {
    exercise bench_press {
        sets:      sets
        reps:      10
        weight:    80.0
        group:     "chest"
        completed: false
    }
}
chest_day("four")
"""

    for name, source in [("valid", valid), ("type_error_weight", invalid), ("type_error_arg", invalid2)]:
        print(f"\n{'='*50}")
        print(f"Test: {name}")
        print('='*50)
        try:
            tokens  = Lexer(source).tokenize()
            ast     = Parser(tokens).parse()
            checker = TypeChecker()
            checker.check(ast)
            print("[OK] Type check passed.")
        except Exception as e:
            print(str(e))
