# =============================================================
#  PumpScript Lexer
#  CSE 341 — Concepts of Programming Languages
#  Gebze Technical University
# =============================================================
#
#  The lexer reads a PumpScript source string character by
#  character and produces a flat list of Token objects.
#
#  Token stream example for "rest 90 seconds":
#    Token(KEYWORD, 'rest',    line=1)
#    Token(INT_LIT, '90',      line=1)
#    Token(KEYWORD, 'seconds', line=1)
#    Token(EOF,     '',        line=1)
# =============================================================


# -------------------------------------------------------------
#  Keywords — these can never be used as identifiers
# -------------------------------------------------------------
KEYWORDS = {
    "routine", "exercise", "rest", "repeat",
    "times", "if", "else", "seconds",
    "true", "false",
    "int", "float", "string", "bool"
}

# -------------------------------------------------------------
#  Two-character operators (must be checked BEFORE one-char)
# -------------------------------------------------------------
TWO_CHAR_OPS = {"==", "!=", ">=", "<="}

# -------------------------------------------------------------
#  One-character operators
# -------------------------------------------------------------
ONE_CHAR_OPS = {"+", "-", "*", "/", ">", "<"}

# -------------------------------------------------------------
#  Separator characters
# -------------------------------------------------------------
SEPARATORS = {"{", "}", "(", ")", ":", ","}


# =============================================================
#  Token — equivalent to a struct in C
# =============================================================
class Token:
    """
    Represents a single lexical token.

    Attributes
    ----------
    type  : str   — one of: KEYWORD, IDENT, INT_LIT, FLOAT_LIT,
                             STRING_LIT, OP, SEP, EOF
    value : str   — the exact text from the source
    line  : int   — source line number (1-based), for error messages
    """

    def __init__(self, type: str, value: str, line: int):
        self.type  = type
        self.value = value
        self.line  = line

    def __repr__(self):
        # Pretty print — useful for --dump-ast and debugging
        return f"Token({self.type:<12} {self.value!r:<20} line={self.line})"


# =============================================================
#  LexerError — raised when an unexpected character is found
# =============================================================
class LexerError(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"[Lexer Error] Line {line}: {message}")
        self.line = line


# =============================================================
#  Lexer
# =============================================================
class Lexer:
    """
    Converts a PumpScript source string into a list of Tokens.

    Usage
    -----
        lexer  = Lexer(source_code)
        tokens = lexer.tokenize()
    """

    def __init__(self, source: str):
        self.source = source   # full source text
        self.pos    = 0        # current character index
        self.line   = 1        # current line number (for errors)

    # ----------------------------------------------------------
    #  Helper: current character
    # ----------------------------------------------------------
    def current(self) -> str:
        """Return the character at the current position, or '' at EOF."""
        if self.pos < len(self.source):
            return self.source[self.pos]
        return ""

    # ----------------------------------------------------------
    #  Helper: peek ahead without advancing
    # ----------------------------------------------------------
    def peek(self) -> str:
        """Return the NEXT character without moving pos."""
        if self.pos + 1 < len(self.source):
            return self.source[self.pos + 1]
        return ""

    # ----------------------------------------------------------
    #  Helper: advance one character
    # ----------------------------------------------------------
    def advance(self) -> str:
        """Consume and return the current character."""
        ch = self.current()
        self.pos += 1
        if ch == "\n":
            self.line += 1   # track line number
        return ch

    # ----------------------------------------------------------
    #  Skip whitespace and single-line comments (//)
    # ----------------------------------------------------------
    def skip_whitespace_and_comments(self):
        """
        Discard spaces, tabs, newlines, and // comments.
        Called before every token read.
        """
        while self.current():
            # Whitespace
            if self.current().isspace():
                self.advance()

            # Single-line comment: // ... end of line
            elif self.current() == "/" and self.peek() == "/":
                while self.current() and self.current() != "\n":
                    self.advance()

            else:
                break   # something meaningful — stop skipping

    # ----------------------------------------------------------
    #  Read identifier or keyword
    # ----------------------------------------------------------
    def read_ident_or_keyword(self) -> Token:
        """
        Consume [a-zA-Z_][a-zA-Z0-9_]* and classify as
        KEYWORD or IDENT.
        """
        start_line = self.line
        value = ""

        # First char: letter or underscore (caller already checked)
        while self.current() and (
            self.current().isalnum() or self.current() == "_"
        ):
            value += self.advance()

        # Is it a reserved keyword?
        if value in KEYWORDS:
            return Token("KEYWORD", value, start_line)
        else:
            return Token("IDENT", value, start_line)

    # ----------------------------------------------------------
    #  Read integer or float literal
    # ----------------------------------------------------------
    def read_number(self) -> Token:
        """
        Consume digits. If a '.' follows, consume a FLOAT_LIT;
        otherwise produce an INT_LIT.
        Maximal munch: '3.14' is one FLOAT_LIT, never split.
        """
        start_line = self.line
        value = ""

        # Integer part
        while self.current() and self.current().isdigit():
            value += self.advance()

        # Fractional part — only if '.' is followed by a digit
        if self.current() == "." and self.peek().isdigit():
            value += self.advance()   # consume '.'
            while self.current() and self.current().isdigit():
                value += self.advance()
            return Token("FLOAT_LIT", value, start_line)

        return Token("INT_LIT", value, start_line)

    # ----------------------------------------------------------
    #  Read string literal
    # ----------------------------------------------------------
    def read_string(self) -> Token:
        """
        Consume "..." and return a STRING_LIT token.
        The opening quote has already been confirmed by the caller.
        Raises LexerError if the string is not closed before EOL/EOF.
        """
        start_line = self.line
        self.advance()   # consume opening '"'
        value = ""

        while self.current() and self.current() not in ('"', "\n"):
            value += self.advance()

        if self.current() != '"':
            raise LexerError(
                f"Unterminated string literal — missing closing '\"'",
                start_line
            )

        self.advance()   # consume closing '"'
        return Token("STRING_LIT", value, start_line)

    # ----------------------------------------------------------
    #  Read one operator token (one or two characters)
    # ----------------------------------------------------------
    def read_operator(self) -> Token:
        """
        Try to match a two-character operator first (maximal munch),
        then fall back to a one-character operator.
        """
        start_line = self.line
        two = self.current() + self.peek()

        if two in TWO_CHAR_OPS:
            self.advance()
            self.advance()
            return Token("OP", two, start_line)

        ch = self.advance()
        return Token("OP", ch, start_line)

    # ----------------------------------------------------------
    #  Main tokenizer loop
    # ----------------------------------------------------------
    def tokenize(self) -> list:
        """
        Consume the entire source and return a list of Token objects.
        The last token is always Token(EOF, '', line).
        Raises LexerError on any unrecognised character.
        """
        tokens = []

        while True:
            self.skip_whitespace_and_comments()

            # End of file
            if not self.current():
                tokens.append(Token("EOF", "", self.line))
                break

            ch = self.current()

            # ── Identifier or keyword ──────────────────────────
            if ch.isalpha() or ch == "_":
                tokens.append(self.read_ident_or_keyword())

            # ── Number literal ─────────────────────────────────
            elif ch.isdigit():
                tokens.append(self.read_number())

            # ── String literal ─────────────────────────────────
            elif ch == '"':
                tokens.append(self.read_string())

            # ── Operator ───────────────────────────────────────
            elif ch in ONE_CHAR_OPS or (ch == "=" and self.peek() == "=") \
                    or (ch == "!" and self.peek() == "="):
                tokens.append(self.read_operator())

            # ── Separator ──────────────────────────────────────
            elif ch in SEPARATORS:
                tokens.append(Token("SEP", self.advance(), self.line))

            # ── Unrecognised character ─────────────────────────
            else:
                raise LexerError(
                    f"Unexpected character '{ch}'",
                    self.line
                )

        return tokens


# =============================================================
#  Quick test — run this file directly: python lexer.py
# =============================================================
if __name__ == "__main__":
    sample = """
// Chest day routine
routine chest_day(sets: int) {
    exercise bench_press {
        sets:      sets
        reps:      10
        weight:    80.0
        group:     "chest"
        completed: false
    }
    rest 60 seconds
}

if true {
    chest_day(4)
}
"""
    lexer  = Lexer(sample)
    tokens = lexer.tokenize()

    print(f"{'TYPE':<14} {'VALUE':<20} {'LINE'}")
    print("-" * 42)
    for tok in tokens:
        print(f"{tok.type:<14} {tok.value!r:<20} {tok.line}")
