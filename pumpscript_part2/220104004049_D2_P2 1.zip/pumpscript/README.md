# PumpScript — Full Interpreter (Part 2)
CSE 341 · Concepts of Programming Languages · Gebze Technical University

## What is PumpScript?
PumpScript is a domain-specific language for defining and managing workout routines.

## Requirements
- Python 3.8 or higher
- No external libraries required

## File Structure
```
pumpscript/
├── pumpscript.py      ← main entry point
├── lexer.py           ← tokenizer (Part 1)
├── parser.py          ← recursive-descent parser (Part 1)
├── ast_nodes.py       ← AST node definitions (Part 1)
├── type_checker.py    ← static type checker (Part 2)
├── interpreter.py     ← tree-walking interpreter (Part 2)
├── README.md          ← this file
└── examples/
    ├── valid1.pump    ← chest day routine
    ├── valid2.pump    ← leg day routine
    ├── valid3.pump    ← full body routine with if/repeat
    ├── type_error.pump← type error example
    ├── error1.pump    ← parse error: missing brace
    ├── error2.pump    ← lexer error: illegal character
    ├── error3.pump    ← parse error: missing type
    ├── error4.pump    ← lexer error: unterminated string
    └── error5.pump    ← parse error: missing parentheses
```

## How to Run

### Run a program (type check + execute):
```bash
python3 pumpscript.py examples/valid1.pump
```

### Parse and dump AST only:
```bash
python3 pumpscript.py examples/valid1.pump --dump-ast
```

### Expected output for a valid program:
```
=============================================
  Exercise: bench_press
=============================================
  sets        : 4
  reps        : 10
  weight      : 80.0 kg
  group       : chest
  completed   : no

  --- Rest: 60 seconds ---
```

### Expected output for a type error:
```
[Type Error] Line 6: In exercise 'squat': field 'weight' expects float but got string
```

### Expected output for a domain-specific runtime error:
```
[Runtime Error] Line 3: In exercise 'squat': 'sets' must be positive, got -1
```


## Final Implemented Scope
- No arrays, no assignment statements, no field access, and no return values.
- Routines are procedures with parameters and no return value.
- Exercise blocks use a fixed schema: `sets:int`, `reps:int`, `weight:float`, `group:string`, `completed:bool`.
- The only implicit coercion is `int -> float`.
- `if` conditions must be `bool`; `repeat` uses an integer literal count.

## Pipeline
```
Source (.pump)
    ↓ Lexer        → tokens
    ↓ Parser       → AST
    ↓ TypeChecker  → type-checked AST
    ↓ Interpreter  → output
```

## Language Overview

### Primitive Types
| Type   | Example        | Use              |
|--------|----------------|------------------|
| int    | 4, 10, 90      | sets, reps       |
| float  | 80.0, 7.5      | weight (kg)      |
| string | "legs", "chest"| muscle group     |
| bool   | true, false    | completed status |

### Structured Type
```
exercise bench_press {
    sets:      4
    reps:      10
    weight:    80.0
    group:     "chest"
    completed: false
}
```

### Control Structures
```
repeat 3 times { ... }
if true { ... } else { ... }
```

### Routines (User-defined functions)
```
routine chest_day(sets: int) {
    exercise bench_press { ... }
    rest 60 seconds
}
chest_day(4)
```

### Domain-specific construct
```
rest 90 seconds   // rest period between exercises
```

## Runtime Errors
- Division by zero: `[Runtime Error] Line N: Division by zero`
- Negative sets/reps: `[Runtime Error] Line N: 'sets' must be positive, got -1`
- Negative weight: `[Runtime Error] Line N: 'weight' cannot be negative, got -50.0`
