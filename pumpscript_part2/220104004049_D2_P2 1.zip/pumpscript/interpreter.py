# =============================================================
#  PumpScript Interpreter
#  CSE 341 — Concepts of Programming Languages
#  Gebze Technical University
# =============================================================
#
#  Tree-walking interpreter.
#  Walks the AST and executes each node.
#
#  Key design decisions:
#  - Static (lexical) scoping: Environment chain
#  - Stack-dynamic lifetime: new env per routine call
#  - Pass-by-value: primitives copied at call time
#  - int → float coercion at runtime
# =============================================================

from ast_nodes import (
    Program, RoutineDecl, Block,
    ExerciseBlock, Field, RestStmt, RepeatStmt,
    IfStmt, RoutineCall,
    BinOp, UnaryOp, Literal, Ident
)


# =============================================================
#  Runtime Error
# =============================================================
class RuntimeErrorPS(Exception):
    def __init__(self, message: str, line: int = 0):
        super().__init__(f"[Runtime Error] Line {line}: {message}")
        self.line = line


# =============================================================
#  Environment — implements static scoping
# =============================================================
class Environment:
    """
    A single scope frame.
    parent → enclosing scope (static scoping chain).

    Variable lookup:
      1. Check current frame
      2. If not found, check parent (and so on)
      3. If not found at all → RuntimeError
    """

    def __init__(self, parent=None):
        self.vars   = {}       # name → value
        self.parent = parent   # enclosing scope

    def get(self, name: str, line: int = 0):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name, line)
        raise RuntimeErrorPS(f"Undefined variable '{name}'", line)

    def set(self, name: str, value):
        self.vars[name] = value

    def set_global(self, name: str, value):
        """Set in the outermost (global) scope."""
        env = self
        while env.parent:
            env = env.parent
        env.vars[name] = value


# =============================================================
#  Interpreter
# =============================================================
class Interpreter:
    """
    Executes a PumpScript AST.

    Usage
    -----
        interp = Interpreter()
        interp.run(ast)
    """

    def __init__(self):
        self.global_env = Environment()   # global scope

    # ----------------------------------------------------------
    #  Entry point
    # ----------------------------------------------------------
    def run(self, program: Program):
        """
        Two-pass execution:
        Pass 1 — register all routine declarations in global scope
        Pass 2 — execute all top-level statements
        """
        # Pass 1: register routines
        for node in program.body:
            if isinstance(node, RoutineDecl):
                self.global_env.set(node.name, node)

        # Pass 2: execute statements
        for node in program.body:
            if not isinstance(node, RoutineDecl):
                self.execute(node, self.global_env)

    # ----------------------------------------------------------
    #  Statement executor
    # ----------------------------------------------------------
    def execute(self, node, env: Environment):
        """Execute a statement node."""

        if isinstance(node, ExerciseBlock):
            self.exec_exercise(node, env)

        elif isinstance(node, RestStmt):
            self.exec_rest(node)

        elif isinstance(node, RepeatStmt):
            self.exec_repeat(node, env)

        elif isinstance(node, IfStmt):
            self.exec_if(node, env)

        elif isinstance(node, RoutineCall):
            self.exec_routine_call(node, env)

        elif isinstance(node, Block):
            for stmt in node.stmts:
                self.execute(stmt, env)

    # ----------------------------------------------------------
    #  Exercise block
    # ----------------------------------------------------------
    def exec_exercise(self, node: ExerciseBlock, env: Environment):
        """
        Evaluate all fields and print the exercise record.
        """
        print(f"\n{'='*45}")
        print(f"  Exercise: {node.name}")
        print(f"{'='*45}")

        for field in node.fields:
            value = self.evaluate(field.value, env)

            # int → float coercion for weight field
            if field.name == "weight" and isinstance(value, int):
                value = float(value)

            # Domain-specific runtime errors
            if field.name in ("sets", "reps"):
                if isinstance(value, int) and value <= 0:
                    raise RuntimeErrorPS(
                        f"In exercise '{node.name}': "
                        f"'{field.name}' must be positive, got {value}",
                        field.line
                    )
            if field.name == "weight":
                if isinstance(value, (int, float)) and value < 0:
                    raise RuntimeErrorPS(
                        f"In exercise '{node.name}': "
                        f"'weight' cannot be negative, got {value}",
                        field.line
                    )

            # Pretty print
            if field.name == "weight":
                print(f"  {field.name:<12}: {value} kg")
            elif field.name == "completed":
                print(f"  {field.name:<12}: {'yes' if value else 'no'}")
            else:
                print(f"  {field.name:<12}: {value}")

    # ----------------------------------------------------------
    #  Rest statement
    # ----------------------------------------------------------
    def exec_rest(self, node: RestStmt):
        print(f"\n  --- Rest: {node.seconds} seconds ---")

    # ----------------------------------------------------------
    #  Repeat statement
    # ----------------------------------------------------------
    def exec_repeat(self, node: RepeatStmt, env: Environment):
        """
        Execute the block node.count times.
        Count is evaluated once before the loop starts.
        """
        count = node.count
        if count < 0:
            raise RuntimeErrorPS(
                f"repeat count must be non-negative, got {count}",
                node.line
            )
        for _ in range(count):
            self.execute(node.body, env)

    # ----------------------------------------------------------
    #  If statement
    # ----------------------------------------------------------
    def exec_if(self, node: IfStmt, env: Environment):
        condition = self.evaluate(node.condition, env)
        if condition:
            self.execute(node.then_block, env)
        elif node.else_block:
            self.execute(node.else_block, env)

    # ----------------------------------------------------------
    #  Routine call
    # ----------------------------------------------------------
    def exec_routine_call(self, node: RoutineCall, env: Environment):
        """
        Static scoping:
        - Look up routine in global scope
        - Create new local env with GLOBAL env as parent
          (not the caller's env — this enforces static scoping)
        - Bind parameters in new local env
        - Execute routine body in new local env
        """
        # Look up routine definition
        try:
            routine = self.global_env.get(node.name, node.line)
        except RuntimeErrorPS:
            raise RuntimeErrorPS(
                f"Undefined routine '{node.name}'",
                node.line
            )

        if not isinstance(routine, RoutineDecl):
            raise RuntimeErrorPS(
                f"'{node.name}' is not a routine",
                node.line
            )

        # Evaluate arguments in CALLER's environment
        arg_values = [self.evaluate(arg, env) for arg in node.args]

        # Check argument count
        if len(arg_values) != len(routine.params):
            raise RuntimeErrorPS(
                f"Routine '{node.name}' expects {len(routine.params)} "
                f"argument(s) but got {len(arg_values)}",
                node.line
            )

        # Create new local env — parent is GLOBAL (static scoping)
        local_env = Environment(parent=self.global_env)

        # Bind parameters (pass-by-value)
        for param, value in zip(routine.params, arg_values):
            # int → float coercion if param type is float
            if param.type_ == "float" and isinstance(value, int):
                value = float(value)
            local_env.set(param.name, value)

        # Execute routine body in local env
        self.execute(routine.body, local_env)

    # ----------------------------------------------------------
    #  Expression evaluator
    # ----------------------------------------------------------
    def evaluate(self, node, env: Environment):
        """
        Evaluate an expression node and return its Python value.
        """

        # Literal value
        if isinstance(node, Literal):
            return node.value

        # Variable lookup
        if isinstance(node, Ident):
            return env.get(node.name, node.line)

        # Unary minus
        if isinstance(node, UnaryOp):
            val = self.evaluate(node.operand, env)
            if node.op == "-":
                return -val
            raise RuntimeErrorPS(f"Unknown unary op '{node.op}'")

        # Binary operation
        if isinstance(node, BinOp):
            return self.eval_binop(node, env)

        raise RuntimeErrorPS(f"Unknown expression node: {type(node).__name__}")

    # ----------------------------------------------------------
    #  Binary operator evaluation
    # ----------------------------------------------------------
    def eval_binop(self, node: BinOp, env: Environment):
        left  = self.evaluate(node.left,  env)
        right = self.evaluate(node.right, env)

        # int + float → float coercion
        if isinstance(left, int) and isinstance(right, float):
            left = float(left)
        elif isinstance(left, float) and isinstance(right, int):
            right = float(right)

        op = node.op
        if op == "+":  return left + right
        if op == "-":  return left - right
        if op == "*":  return left * right
        if op == "/":
            if right == 0:
                raise RuntimeErrorPS("Division by zero", node.line)
            return left / right
        if op == "==": return left == right
        if op == "!=": return left != right
        if op == ">":  return left > right
        if op == "<":  return left < right
        if op == ">=": return left >= right
        if op == "<=": return left <= right

        raise RuntimeErrorPS(f"Unknown operator '{op}'", node.line)


# =============================================================
#  Quick test — python interpreter.py
# =============================================================
if __name__ == "__main__":
    from lexer         import Lexer
    from parser        import Parser
    from type_checker  import TypeChecker

    source = """
// Chest day routine
routine chest_day(sets: int) {
    exercise bench_press {
        sets:      sets
        reps:      10
        weight:    80.0
        group:     "chest"
        completed: false
    }
    rest 60 seconds
    exercise chest_fly {
        sets:      sets
        reps:      12
        weight:    20.0
        group:     "chest"
        completed: false
    }
}

if true {
    chest_day(4)
}
"""
    tokens  = Lexer(source).tokenize()
    ast     = Parser(tokens).parse()
    checker = TypeChecker()
    checker.check(ast)
    interp  = Interpreter()
    interp.run(ast)
