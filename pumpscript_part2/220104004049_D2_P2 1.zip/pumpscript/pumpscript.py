# =============================================================
#  PumpScript — Main Entry Point (Part 2)
#  CSE 341 — Concepts of Programming Languages
# =============================================================
import sys
from lexer         import Lexer,        LexerError
from parser        import Parser,       ParseError
from type_checker  import TypeChecker,  TypeErrorPS
from interpreter   import Interpreter,  RuntimeErrorPS

def main():
    args = sys.argv[1:]
    if not args:
        print("Usage: python3 pumpscript.py <file.pump> [--dump-ast]")
        sys.exit(1)

    source_file = args[0]
    dump_ast    = "--dump-ast" in args

    try:
        with open(source_file, "r", encoding="utf-8") as f:
            source = f.read()
    except FileNotFoundError:
        print(f"[Error] File not found: '{source_file}'")
        sys.exit(1)

    try:
        tokens = Lexer(source).tokenize()
    except LexerError as e:
        print(str(e)); sys.exit(1)

    try:
        ast = Parser(tokens).parse()
    except ParseError as e:
        print(str(e)); sys.exit(1)

    if dump_ast:
        print(ast.dump())
        return

    try:
        TypeChecker().check(ast)
    except TypeErrorPS as e:
        print(str(e)); sys.exit(1)

    try:
        Interpreter().run(ast)
    except RuntimeErrorPS as e:
        print(str(e)); sys.exit(1)

if __name__ == "__main__":
    main()
